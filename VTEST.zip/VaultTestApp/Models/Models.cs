namespace VaultTestApp.Models;

public class VaultCredentials
{
    public string VaultEndpoint { get; set; } = string.Empty;
    public string RoleId        { get; set; } = string.Empty;
    public string SecretId      { get; set; } = string.Empty;
    public string SecretPath    { get; set; } = string.Empty;
    public string KeyField      { get; set; } = "active_key";
    public string PlainText     { get; set; } = string.Empty;
    public string CipherText    { get; set; } = string.Empty;
}

public class ApiResult
{
    public bool   Success { get; set; }
    public string Result  { get; set; } = string.Empty;
    public string Error   { get; set; } = string.Empty;
}
