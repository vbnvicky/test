using Microsoft.AspNetCore.Mvc;
using VaultTestApp.Models;
using VaultTestApp.Services;

namespace VaultTestApp.Controllers;

[ApiController]
[Route("api/vault")]
public class VaultController : ControllerBase
{
    [HttpPost("encrypt")]
    public async Task<ApiResult> Encrypt([FromBody] VaultCredentials req, CancellationToken ct)
    {
        try
        {
            var result = await VaultEncryptor.EncryptAsync(
                req.VaultEndpoint, req.RoleId, req.SecretId,
                req.SecretPath, req.KeyField, req.PlainText, ct);
            return new ApiResult { Success = true, Result = result };
        }
        catch (Exception ex)
        {
            return new ApiResult { Success = false, Error = ex.Message };
        }
    }

    [HttpPost("decrypt")]
    public async Task<ApiResult> Decrypt([FromBody] VaultCredentials req, CancellationToken ct)
    {
        try
        {
            var result = await VaultEncryptor.DecryptAsync(
                req.VaultEndpoint, req.RoleId, req.SecretId,
                req.SecretPath, req.KeyField, req.CipherText, ct);
            return new ApiResult { Success = true, Result = result };
        }
        catch (Exception ex)
        {
            return new ApiResult { Success = false, Error = ex.Message };
        }
    }
}
