using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace VaultTestApp.Services;

public static class VaultEncryptor
{
    private const int IvSize  = 12;
    private const int TagSize = 16;

    private static string? _token;
    private static DateTime _tokenExpiresAt = DateTime.MinValue;
    private static readonly SemaphoreSlim _tokenLock = new(1, 1);

    public static async Task<string> EncryptAsync(
        string vaultEndpoint, string roleId, string secretId,
        string secretPath, string keyField, string plainText,
        CancellationToken ct = default)
    {
        var keyBytes   = await FetchKeyAsync(vaultEndpoint, roleId, secretId, secretPath, keyField, ct);
        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var iv         = RandomNumberGenerator.GetBytes(IvSize);
        var cipher     = new byte[plainBytes.Length];
        var tag        = new byte[TagSize];

        using var aes = new AesGcm(keyBytes, TagSize);
        aes.Encrypt(iv, plainBytes, cipher, tag);

        var packed = new byte[IvSize + cipher.Length + TagSize];
        Buffer.BlockCopy(iv,     0, packed, 0,                      IvSize);
        Buffer.BlockCopy(cipher, 0, packed, IvSize,                 cipher.Length);
        Buffer.BlockCopy(tag,    0, packed, IvSize + cipher.Length, TagSize);

        return Convert.ToBase64String(packed);
    }

    public static async Task<string> DecryptAsync(
        string vaultEndpoint, string roleId, string secretId,
        string secretPath, string keyField, string cipherText,
        CancellationToken ct = default)
    {
        var keyBytes = await FetchKeyAsync(vaultEndpoint, roleId, secretId, secretPath, keyField, ct);

        byte[] packed;
        try   { packed = Convert.FromBase64String(cipherText); }
        catch { throw new ArgumentException("CipherText is not valid base64."); }

        if (packed.Length < IvSize + TagSize + 1)
            throw new ArgumentException("CipherText is too short.");

        var cipherLen  = packed.Length - IvSize - TagSize;
        var iv         = new byte[IvSize];
        var cipher     = new byte[cipherLen];
        var tag        = new byte[TagSize];
        var plainBytes = new byte[cipherLen];

        Buffer.BlockCopy(packed, 0,                  iv,     0, IvSize);
        Buffer.BlockCopy(packed, IvSize,             cipher, 0, cipherLen);
        Buffer.BlockCopy(packed, IvSize + cipherLen, tag,    0, TagSize);

        using var aes = new AesGcm(keyBytes, TagSize);
        try   { aes.Decrypt(iv, cipher, tag, plainBytes); }
        catch (AuthenticationTagMismatchException)
        {
            throw new CryptographicException("Decryption failed: key may have rotated or data is tampered.");
        }

        return Encoding.UTF8.GetString(plainBytes);
    }

    private static async Task<byte[]> FetchKeyAsync(
        string endpoint, string roleId, string secretId,
        string secretPath, string keyField, CancellationToken ct)
    {
        var token = await EnsureTokenAsync(endpoint, roleId, secretId, ct);

        using var http = MakeClient(endpoint);
        var req = new HttpRequestMessage(HttpMethod.Get, $"/v1/{secretPath}");
        req.Headers.Add("X-Vault-Token", token);

        var res  = await http.SendAsync(req, ct);
        var body = await res.Content.ReadAsStringAsync(ct);

        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException($"Vault key fetch failed ({(int)res.StatusCode}): {body}");

        var doc  = JsonDocument.Parse(body);
        var data = doc.RootElement.GetProperty("data").GetProperty("data");

        if (!data.TryGetProperty(keyField, out var keyEl))
            throw new InvalidOperationException($"Field '{keyField}' not found in Vault secret.");

        return ParseKey(keyEl.GetString() ?? throw new InvalidOperationException("Key is null."));
    }

    private static async Task<string> EnsureTokenAsync(
        string endpoint, string roleId, string secretId, CancellationToken ct)
    {
        await _tokenLock.WaitAsync(ct);
        try
        {
            if (_token is not null && _tokenExpiresAt > DateTime.UtcNow.AddSeconds(60))
                return _token;

            using var http    = MakeClient(endpoint);
            var payload       = JsonSerializer.Serialize(new { role_id = roleId, secret_id = secretId });
            var req           = new HttpRequestMessage(HttpMethod.Post, "/v1/auth/approle/login")
                                { Content = new StringContent(payload, Encoding.UTF8, "application/json") };

            var res  = await http.SendAsync(req, ct);
            var body = await res.Content.ReadAsStringAsync(ct);

            if (!res.IsSuccessStatusCode)
                throw new HttpRequestException($"Vault login failed ({(int)res.StatusCode}): {body}");

            var auth        = JsonDocument.Parse(body).RootElement.GetProperty("auth");
            _token          = auth.GetProperty("client_token").GetString()!;
            _tokenExpiresAt = DateTime.UtcNow.AddSeconds(auth.GetProperty("lease_duration").GetInt32());
            return _token;
        }
        finally { _tokenLock.Release(); }
    }

    private static byte[] ParseKey(string raw)
    {
        raw = raw.Trim();
        if (raw.Length == 64 && raw.All(Uri.IsHexDigit))
            return Convert.FromHexString(raw);
        try
        {
            var bytes = Convert.FromBase64String(raw);
            if (bytes.Length is not (16 or 24 or 32))
                throw new InvalidOperationException($"Key must be 128/192/256 bits. Got {bytes.Length * 8}.");
            return bytes;
        }
        catch (FormatException) { throw new InvalidOperationException("Key is not valid hex or base64."); }
    }

    private static HttpClient MakeClient(string endpoint) => new()
    {
        BaseAddress = new Uri(endpoint),
        Timeout     = TimeSpan.FromSeconds(15)
    };
}
