using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace HasiCorp.Wallet;

/// <summary>
/// Drop-in HashiCorp Vault AES-256-GCM encryptor.
///
/// USAGE — one-time setup (e.g. in Program.cs or Startup):
///
///     await VaultEncryptor.InitAsync(
///         vaultEndpoint : "https://vault.example.com",
///         roleId        : "your-role-id",
///         secretId      : "your-secret-id",
///         secretPath    : "secret/data/hasi-corp/wallet-key",
///         keyField      : "active_key"          // optional, default = "active_key"
///     );
///
/// ENCRYPT anywhere in your app:
///
///     string cipher = await VaultEncryptor.EncryptAsync("hello world");
///
/// DECRYPT anywhere in your app:
///
///     string plain  = await VaultEncryptor.DecryptAsync(cipher);
///
/// </summary>
public static class VaultEncryptor
{
    // ── AES-GCM constants ────────────────────────────────────
    private const int IvSize  = 12;   // 96-bit nonce (NIST recommended)
    private const int TagSize = 16;   // 128-bit auth tag

    // ── Vault token cache ────────────────────────────────────
    private static string?   _token;
    private static DateTime  _tokenExpiresAt = DateTime.MinValue;
    private static readonly SemaphoreSlim _tokenLock = new(1, 1);

    // ── Config (set once via InitAsync) ─────────────────────
    private static string _endpoint   = string.Empty;
    private static string _roleId     = string.Empty;
    private static string _secretId   = string.Empty;
    private static string _secretPath = string.Empty;
    private static string _keyField   = "active_key";
    private static string _authMount  = "approle";

    private static bool _initialized = false;

    // ─────────────────────────────────────────────────────────
    // Init
    // ─────────────────────────────────────────────────────────

    /// <summary>
    /// Call once at app startup to configure Vault connection.
    /// Validates the connection by doing a test key fetch.
    /// </summary>
    public static async Task InitAsync(
        string vaultEndpoint,
        string roleId,
        string secretId,
        string secretPath,
        string keyField   = "active_key",
        string authMount  = "approle",
        CancellationToken ct = default)
    {
        _endpoint   = vaultEndpoint.TrimEnd('/');
        _roleId     = roleId;
        _secretId   = secretId;
        _secretPath = secretPath;
        _keyField   = keyField;
        _authMount  = authMount;
        _initialized = true;

        // Validate connection eagerly
        await FetchKeyAsync(ct);
    }

    // ─────────────────────────────────────────────────────────
    // Public API — Encrypt / Decrypt
    // ─────────────────────────────────────────────────────────

    /// <summary>
    /// Encrypts <paramref name="plainText"/> using the active Vault key.
    /// Returns a base64 string: [ IV | ciphertext | GCM-tag ]
    /// </summary>
    public static async Task<string> EncryptAsync(string plainText, CancellationToken ct = default)
    {
        EnsureInitialized();
        ArgumentException.ThrowIfNullOrWhiteSpace(plainText);

        var keyBytes   = await FetchKeyAsync(ct);
        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var iv         = RandomNumberGenerator.GetBytes(IvSize);
        var cipher     = new byte[plainBytes.Length];
        var tag        = new byte[TagSize];

        using var aes = new AesGcm(keyBytes, TagSize);
        aes.Encrypt(iv, plainBytes, cipher, tag);

        // Pack: IV | ciphertext | tag → one base64 blob
        var packed = new byte[IvSize + cipher.Length + TagSize];
        Buffer.BlockCopy(iv,     0, packed, 0,                      IvSize);
        Buffer.BlockCopy(cipher, 0, packed, IvSize,                 cipher.Length);
        Buffer.BlockCopy(tag,    0, packed, IvSize + cipher.Length, TagSize);

        return Convert.ToBase64String(packed);
    }

    /// <summary>
    /// Decrypts a base64 ciphertext produced by <see cref="EncryptAsync"/>.
    /// Throws <see cref="CryptographicException"/> if the key has rotated or data is tampered.
    /// </summary>
    public static async Task<string> DecryptAsync(string cipherText, CancellationToken ct = default)
    {
        EnsureInitialized();
        ArgumentException.ThrowIfNullOrWhiteSpace(cipherText);

        var keyBytes = await FetchKeyAsync(ct);

        byte[] packed;
        try   { packed = Convert.FromBase64String(cipherText); }
        catch { throw new ArgumentException("CipherText is not valid base64."); }

        if (packed.Length < IvSize + TagSize + 1)
            throw new ArgumentException("CipherText is too short to be valid.");

        var cipherLen  = packed.Length - IvSize - TagSize;
        var iv         = new byte[IvSize];
        var cipher     = new byte[cipherLen];
        var tag        = new byte[TagSize];
        var plainBytes = new byte[cipherLen];

        Buffer.BlockCopy(packed, 0,                  iv,     0, IvSize);
        Buffer.BlockCopy(packed, IvSize,             cipher, 0, cipherLen);
        Buffer.BlockCopy(packed, IvSize + cipherLen, tag,    0, TagSize);

        using var aes = new AesGcm(keyBytes, TagSize);
        try
        {
            aes.Decrypt(iv, cipher, tag, plainBytes);
        }
        catch (AuthenticationTagMismatchException)
        {
            throw new CryptographicException(
                "Decryption failed: authentication tag mismatch. " +
                "Key may have rotated since encryption.");
        }

        return Encoding.UTF8.GetString(plainBytes);
    }

    // ─────────────────────────────────────────────────────────
    // Vault: AppRole login + key fetch (internal)
    // ─────────────────────────────────────────────────────────

    private static async Task<byte[]> FetchKeyAsync(CancellationToken ct)
    {
        var token = await EnsureTokenAsync(ct);

        using var http = MakeClient();
        var req = new HttpRequestMessage(HttpMethod.Get, $"/v1/{_secretPath}");
        req.Headers.Add("X-Vault-Token", token);

        var res  = await http.SendAsync(req, ct);
        var body = await res.Content.ReadAsStringAsync(ct);

        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException($"Vault key fetch failed ({(int)res.StatusCode}): {body}");

        var doc     = JsonDocument.Parse(body);
        var dataObj = doc.RootElement
                        .GetProperty("data")
                        .GetProperty("data");

        if (!dataObj.TryGetProperty(_keyField, out var keyEl))
            throw new InvalidOperationException(
                $"Field '{_keyField}' not found in Vault secret '{_secretPath}'.");

        return ParseKey(keyEl.GetString()
            ?? throw new InvalidOperationException("Key field is null."));
    }

    private static async Task<string> EnsureTokenAsync(CancellationToken ct)
    {
        await _tokenLock.WaitAsync(ct);
        try
        {
            // Renew if expiring within 60 seconds
            if (_token is not null && _tokenExpiresAt > DateTime.UtcNow.AddSeconds(60))
                return _token;

            using var http = MakeClient();
            var payload = JsonSerializer.Serialize(new
            {
                role_id   = _roleId,
                secret_id = _secretId
            });

            var req = new HttpRequestMessage(HttpMethod.Post, $"/v1/auth/{_authMount}/login")
            {
                Content = new StringContent(payload, Encoding.UTF8, "application/json")
            };

            var res  = await http.SendAsync(req, ct);
            var body = await res.Content.ReadAsStringAsync(ct);

            if (!res.IsSuccessStatusCode)
                throw new HttpRequestException($"Vault AppRole login failed ({(int)res.StatusCode}): {body}");

            var doc  = JsonDocument.Parse(body);
            var auth = doc.RootElement.GetProperty("auth");

            _token          = auth.GetProperty("client_token").GetString()
                ?? throw new InvalidOperationException("client_token missing in Vault response.");
            _tokenExpiresAt = DateTime.UtcNow.AddSeconds(auth.GetProperty("lease_duration").GetInt32());

            return _token;
        }
        finally
        {
            _tokenLock.Release();
        }
    }

    // ─────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────

    /// <summary>Accepts key as hex (64 chars) or base64 (44 chars for 32 bytes).</summary>
    private static byte[] ParseKey(string raw)
    {
        raw = raw.Trim();

        if (raw.Length == 64 && raw.All(Uri.IsHexDigit))
            return Convert.FromHexString(raw);

        try
        {
            var bytes = Convert.FromBase64String(raw);
            if (bytes.Length is not (16 or 24 or 32))
                throw new InvalidOperationException(
                    $"Key must be 128/192/256 bits. Got {bytes.Length * 8} bits.");
            return bytes;
        }
        catch (FormatException)
        {
            throw new InvalidOperationException("Vault key is neither valid hex (64 chars) nor base64.");
        }
    }

    private static HttpClient MakeClient()
    {
        var client = new HttpClient { BaseAddress = new Uri(_endpoint), Timeout = TimeSpan.FromSeconds(15) };
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        return client;
    }

    private static void EnsureInitialized()
    {
        if (!_initialized)
            throw new InvalidOperationException(
                "VaultEncryptor not initialized. Call VaultEncryptor.InitAsync(...) at app startup.");
    }
}
