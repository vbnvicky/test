using System.Text;
using System.Text.Json;

namespace YourApp.Vault;

/// <summary>
/// Authenticates to HashiCorp Vault via AppRole and fetches secrets from KV v2.
/// Token is cached and auto-renewed before expiry.
/// </summary>
public interface IVaultSecretService
{
    Task<string> GetSecretAsync(string path, string key, CancellationToken ct = default);
}

public sealed class VaultSecretService : IVaultSecretService, IDisposable
{
    private readonly string     _endpoint;
    private readonly string     _roleId;
    private readonly string     _secretId;
    private readonly string     _authMount;
    private readonly ILogger<VaultSecretService> _log;

    private string?  _token;
    private DateTime _tokenExpiresAt = DateTime.MinValue;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public VaultSecretService(
        string endpoint,
        string roleId,
        string secretId,
        ILogger<VaultSecretService> logger,
        string authMount = "approle")
    {
        _endpoint  = endpoint.TrimEnd('/');
        _roleId    = roleId;
        _secretId  = secretId;
        _authMount = authMount;
        _log       = logger;
    }

    // ── Public ───────────────────────────────────────────────────────────────

    public async Task<string> GetSecretAsync(string path, string key, CancellationToken ct = default)
    {
        var token = await EnsureTokenAsync(ct);
        return await FetchFieldAsync(token, path, key, ct);
    }

    // ── AppRole login ─────────────────────────────────────────────────────────

    private async Task<string> EnsureTokenAsync(CancellationToken ct)
    {
        await _lock.WaitAsync(ct);
        try
        {
            // Renew if expiring within 60 seconds
            if (_token is not null && _tokenExpiresAt > DateTime.UtcNow.AddSeconds(60))
                return _token;

            _log.LogInformation("Authenticating with Vault via AppRole...");

            using var http = MakeClient();
            var body = JsonSerializer.Serialize(new
            {
                role_id   = _roleId,
                secret_id = _secretId
            });

            var request = new HttpRequestMessage(HttpMethod.Post, $"/v1/auth/{_authMount}/login")
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json")
            };

            var response = await http.SendAsync(request, ct);
            var content  = await response.Content.ReadAsStringAsync(ct);

            if (!response.IsSuccessStatusCode)
                throw new HttpRequestException(
                    $"Vault AppRole login failed ({(int)response.StatusCode}): {content}");

            var auth        = JsonDocument.Parse(content).RootElement.GetProperty("auth");
            _token          = auth.GetProperty("client_token").GetString()
                              ?? throw new InvalidOperationException("Vault returned null token.");
            _tokenExpiresAt = DateTime.UtcNow.AddSeconds(
                              auth.GetProperty("lease_duration").GetInt32());

            _log.LogInformation("Vault token acquired. Expires at {Expiry:u}", _tokenExpiresAt);
            return _token;
        }
        finally { _lock.Release(); }
    }

    // ── KV v2 secret fetch ────────────────────────────────────────────────────

    private async Task<string> FetchFieldAsync(string token, string path, string key, CancellationToken ct)
    {
        _log.LogDebug("Fetching Vault secret: {Path}#{Key}", path, key);

        using var http    = MakeClient();
        var request       = new HttpRequestMessage(HttpMethod.Get, $"/v1/{path}");
        request.Headers.Add("X-Vault-Token", token);

        var response = await http.SendAsync(request, ct);
        var content  = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException(
                $"Vault secret fetch failed for '{path}' ({(int)response.StatusCode}): {content}");

        var doc  = JsonDocument.Parse(content);
        var data = doc.RootElement.GetProperty("data").GetProperty("data");

        if (!data.TryGetProperty(key, out var field))
            throw new InvalidOperationException(
                $"Field '{key}' not found in Vault secret at '{path}'.");

        return field.GetString()
               ?? throw new InvalidOperationException($"Field '{key}' is null in Vault.");
    }

    private HttpClient MakeClient() => new()
    {
        BaseAddress = new Uri(_endpoint),
        Timeout     = TimeSpan.FromSeconds(15)
    };

    public void Dispose() => _lock.Dispose();
}
