using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace YourApp.Vault;

/// <summary>
/// Extension methods for wiring Vault secret resolution into Program.cs.
///
/// ── USAGE in Program.cs ─────────────────────────────────────────────────────
///
///   // Option 1 — IConfiguration only (simplest, covers most cases)
///   await builder.ResolveVaultSecretsAsync();
///
///   // Option 2 — IConfiguration + strongly typed object
///   var mySettings = new MyAppSettings();
///   builder.Configuration.GetSection("MyApp").Bind(mySettings);
///   await builder.ResolveVaultSecretsAsync(mySettings);
///   builder.Services.AddSingleton(mySettings);  // inject the resolved object
///
/// ── appsettings.json ─────────────────────────────────────────────────────────
///
///   "Vault": {
///     "Endpoint": "https://vault-enterprise.onefiserv.net",
///     "RoleId":   "your-role-id",
///     "SecretId": "your-secret-id"          ← set via env var in production
///   },
///   "ExternalServices": {
///     "SomeApi": {
///       "Password": "vault:secret/data/myapp/creds#api_password"
///     }
///   }
///
/// ── Environment variable for SecretId (production) ───────────────────────────
///
///   Windows:  set Vault__SecretId=your-secret-id
///   Linux:    export Vault__SecretId=your-secret-id
///   Pipeline: set as environment variable in CI/CD step
///
/// </summary>
public static class VaultStartupExtensions
{
    /// <summary>
    /// Reads Vault config from appsettings.json, authenticates, and resolves
    /// all vault: references in IConfiguration (and optionally a typed object).
    ///
    /// Call this in Program.cs BEFORE builder.Build().
    /// </summary>
    public static async Task ResolveVaultSecretsAsync(
        this WebApplicationBuilder builder,
        object? typedSettingsObject = null,
        CancellationToken ct = default)
    {
        var config = builder.Configuration;

        // ── Read Vault connection config ──────────────────────────────────────
        var endpoint = config["Vault:Endpoint"]
            ?? throw new InvalidOperationException(
                "Vault:Endpoint is missing from appsettings.json");

        var roleId = config["Vault:RoleId"]
            ?? throw new InvalidOperationException(
                "Vault:RoleId is missing from appsettings.json");

        // SecretId should come from env var in production
        // Falls back to appsettings.json for local dev only
        var secretId = config["Vault:SecretId"]
            ?? throw new InvalidOperationException(
                "Vault:SecretId is missing. Set it as an environment variable: Vault__SecretId");

        var authMount = config["Vault:AuthMount"] ?? "approle";

        // ── Build a temporary logger (builder not yet built) ──────────────────
        using var logFactory = LoggerFactory.Create(b => b
            .AddConsole()
            .SetMinimumLevel(LogLevel.Information));

        var logger = logFactory.CreateLogger<VaultSecretService>();

        // ── Create Vault service ──────────────────────────────────────────────
        using var vaultService = new VaultSecretService(
            endpoint, roleId, secretId, logger, authMount);

        // ── Resolve all vault: references ─────────────────────────────────────
        var log = await VaultConfigResolver.ResolveAllAsync(
            config, vaultService, typedSettingsObject, ct);

        // ── Log results ───────────────────────────────────────────────────────
        var appLogger = logFactory.CreateLogger("VaultStartup");

        int resolved = 0, failed = 0;
        foreach (var entry in log)
        {
            if (entry.Success)
            {
                appLogger.LogInformation(
                    "[Vault] ✓ Resolved {Key} from {Ref} → {Masked}",
                    entry.ConfigKey, entry.VaultReference, entry.MaskedValue);
                resolved++;
            }
            else
            {
                appLogger.LogError(
                    "[Vault] ✗ FAILED to resolve {Key} from {Ref}: {Error}",
                    entry.ConfigKey, entry.VaultReference, entry.Error);
                failed++;
            }
        }

        appLogger.LogInformation(
            "[Vault] Resolution complete — {Resolved} resolved, {Failed} failed.",
            resolved, failed);

        if (failed > 0)
            throw new InvalidOperationException(
                $"Vault secret resolution failed for {failed} secret(s). " +
                "Check logs for details. App cannot start with unresolved secrets.");
    }
}
