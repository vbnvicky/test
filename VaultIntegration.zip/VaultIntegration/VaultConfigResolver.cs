using System.Reflection;
using Microsoft.Extensions.Configuration;

namespace YourApp.Vault;

/// <summary>
/// Resolves vault: references at app startup.
///
/// Supports TWO patterns used in real projects:
///
/// ── Pattern A: Strongly typed settings (IOptions) ──────────────────────────
///
///   await VaultConfigResolver.ResolveObjectAsync(mySettingsInstance, vaultService);
///   // All string properties with vault: values are replaced in memory.
///   // Business code reads .Password normally — no changes needed.
///
/// ── Pattern B: IConfiguration ──────────────────────────────────────────────
///
///   await VaultConfigResolver.ResolveConfigurationAsync(configuration, vaultService);
///   // Scans all config keys. vault: values are resolved and overwritten
///   // in the in-memory config. config["Section:Password"] returns real value.
///
/// ── Both together (recommended for mixed projects) ─────────────────────────
///
///   await VaultConfigResolver.ResolveAllAsync(configuration, vaultService);
///
/// </summary>
public static class VaultConfigResolver
{
    // ── Pattern A: Strongly typed object (via Reflection) ────────────────────

    /// <summary>
    /// Walks all string properties on a settings object recursively.
    /// Any property whose value starts with "vault:" is resolved and replaced in memory.
    /// </summary>
    public static async Task<List<ResolvedEntry>> ResolveObjectAsync(
        object target,
        IVaultSecretService vault,
        CancellationToken ct = default)
    {
        var log = new List<ResolvedEntry>();
        await WalkObjectAsync(target, vault, log, ct);
        return log;
    }

    private static async Task WalkObjectAsync(
        object? target,
        IVaultSecretService vault,
        List<ResolvedEntry> log,
        CancellationToken ct)
    {
        if (target is null) return;

        var props = target.GetType()
            .GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.CanRead && p.CanWrite);

        foreach (var prop in props)
        {
            if (prop.PropertyType == typeof(string))
            {
                var value = prop.GetValue(target) as string;
                if (!VaultReferenceParser.IsVaultReference(value)) continue;

                var entry = await ResolveReferenceAsync(value!, vault, prop.Name, ct);
                if (entry.Success)
                    prop.SetValue(target, entry.ResolvedValue);

                log.Add(entry);
            }
            else if (!prop.PropertyType.IsPrimitive
                     && prop.PropertyType != typeof(decimal)
                     && prop.PropertyType != typeof(DateTime)
                     && !prop.PropertyType.IsEnum)
            {
                var child = prop.GetValue(target);
                if (child is not null)
                    await WalkObjectAsync(child, vault, log, ct);
            }
        }
    }

    // ── Pattern B: IConfiguration (in-memory override) ───────────────────────

    /// <summary>
    /// Scans every key in IConfiguration.
    /// vault: values are resolved and written back via MemoryConfigurationProvider override.
    /// After this call, config["Section:Password"] returns the real secret.
    /// </summary>
    public static async Task<List<ResolvedEntry>> ResolveConfigurationAsync(
        IConfiguration configuration,
        IVaultSecretService vault,
        CancellationToken ct = default)
    {
        var log       = new List<ResolvedEntry>();
        var overrides = new Dictionary<string, string?>();

        foreach (var kvp in configuration.AsEnumerable())
        {
            if (!VaultReferenceParser.IsVaultReference(kvp.Value)) continue;

            var entry = await ResolveReferenceAsync(kvp.Value!, vault, kvp.Key, ct);
            log.Add(entry);

            if (entry.Success)
                overrides[kvp.Key] = entry.ResolvedValue;
        }

        // Inject resolved values back into the configuration pipeline
        if (overrides.Count > 0)
        {
            ((IConfigurationBuilder)new ConfigurationBuilder())
                .AddInMemoryCollection(overrides)
                .Build();

            // Override in the live configuration using the root
            var root = configuration as IConfigurationRoot;
            if (root is not null)
            {
                foreach (var kv in overrides)
                    configuration[kv.Key] = kv.Value;
            }
        }

        return log;
    }

    // ── Both patterns combined ────────────────────────────────────────────────

    /// <summary>
    /// Runs both IConfiguration scan AND object resolution.
    /// Use this when your project mixes IConfiguration and IOptions.
    /// </summary>
    public static async Task<List<ResolvedEntry>> ResolveAllAsync(
        IConfiguration configuration,
        IVaultSecretService vault,
        object? settingsObject = null,
        CancellationToken ct = default)
    {
        var log = new List<ResolvedEntry>();

        // Resolve IConfiguration keys
        log.AddRange(await ResolveConfigurationAsync(configuration, vault, ct));

        // Also resolve typed object if provided
        if (settingsObject is not null)
        {
            var objLog = await ResolveObjectAsync(settingsObject, vault, ct);
            // Merge — avoid duplicate entries for the same reference
            foreach (var e in objLog)
                if (!log.Any(x => x.VaultReference == e.VaultReference))
                    log.Add(e);
        }

        return log;
    }

    // ── Shared resolution helper ──────────────────────────────────────────────

    private static async Task<ResolvedEntry> ResolveReferenceAsync(
        string vaultRef,
        IVaultSecretService vault,
        string configKey,
        CancellationToken ct)
    {
        var entry = new ResolvedEntry
        {
            ConfigKey      = configKey,
            VaultReference = vaultRef
        };

        try
        {
            var (path, key)    = VaultReferenceParser.Parse(vaultRef);
            entry.ResolvedValue = await vault.GetSecretAsync(path, key, ct);
            entry.Success       = true;
        }
        catch (Exception ex)
        {
            entry.Success      = false;
            entry.Error        = ex.Message;
        }

        return entry;
    }
}

// ── Result model ─────────────────────────────────────────────────────────────

public class ResolvedEntry
{
    public string ConfigKey      { get; set; } = string.Empty;
    public string VaultReference { get; set; } = string.Empty;
    public string ResolvedValue  { get; set; } = string.Empty;
    public bool   Success        { get; set; }
    public string Error          { get; set; } = string.Empty;

    /// <summary>Safe for logging — shows first 4 chars then stars.</summary>
    public string MaskedValue => Success && !string.IsNullOrEmpty(ResolvedValue)
        ? ResolvedValue[..Math.Min(4, ResolvedValue.Length)]
          + new string('*', Math.Min(ResolvedValue.Length - 4, 8))
        : "(not resolved)";
}
