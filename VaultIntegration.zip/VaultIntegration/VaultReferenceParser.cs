namespace YourApp.Vault;

/// <summary>
/// Parses vault: reference strings.
/// Format: vault:{kv-v2-path}#{field-name}
/// Example: vault:secret/data/myapp/creds#db_password
/// </summary>
public static class VaultReferenceParser
{
    private const string Prefix = "vault:";

    public static bool IsVaultReference(string? value) =>
        !string.IsNullOrWhiteSpace(value) &&
        value.StartsWith(Prefix, StringComparison.OrdinalIgnoreCase);

    public static (string Path, string Key) Parse(string value)
    {
        var raw   = value[Prefix.Length..];
        var parts = raw.Split('#', 2);

        if (parts.Length != 2 ||
            string.IsNullOrWhiteSpace(parts[0]) ||
            string.IsNullOrWhiteSpace(parts[1]))
            throw new ArgumentException(
                $"Invalid vault reference '{value}'. Expected format: vault:path#key");

        return (parts[0].Trim(), parts[1].Trim());
    }
}
