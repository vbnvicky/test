# How to integrate Vault secret resolution into your existing project

## What you get after this integration

- `appsettings.json` has `vault:path#key` instead of plaintext passwords
- At startup, all `vault:` values are fetched from Vault and replaced **in memory**
- **Zero changes** to your business code — `config["Section:Password"]` still works
- If Vault is unreachable at startup, app refuses to start (fail-fast)

---

## Step 1 — Copy these 4 files into your project

Drop all 4 files into a `Vault/` folder inside your existing project:

```
YourExistingProject/
├── Controllers/
├── Services/
├── Vault/                         ← create this folder
│   ├── VaultReferenceParser.cs    ← copy here
│   ├── VaultSecretService.cs      ← copy here
│   ├── VaultConfigResolver.cs     ← copy here
│   └── VaultStartupExtensions.cs  ← copy here
├── appsettings.json
└── Program.cs
```

---

## Step 2 — Change the namespace in all 4 files

Open each file and change:
```csharp
namespace YourApp.Vault;
```
to match your project namespace, for example:
```csharp
namespace Apigee.SPEP.Vault;
```

---

## Step 3 — Update appsettings.json

### Add the Vault connection block:
```json
"Vault": {
  "Endpoint":  "https://vault-enterprise.onefiserv.net",
  "RoleId":    "48148782-6314-d0a1-8126-ac6bd814de02",
  "SecretId":  "SET_VIA_ENVIRONMENT_VARIABLE",
  "AuthMount": "approle"
}
```

### Replace plaintext passwords with vault: references:

BEFORE:
```json
"ExternalServices": {
  "ApigeeGateway": {
    "UserName": "svc_account",
    "Password": "MyPlainTextPassword123"
  },
  "Database": {
    "ConnectionString": "Server=prod-db;Password=DbPass123;"
  }
}
```

AFTER:
```json
"ExternalServices": {
  "ApigeeGateway": {
    "UserName": "svc_account",
    "Password": "vault:secret/data/apigee/credentials#api_password"
  },
  "Database": {
    "ConnectionString": "vault:secret/data/apigee/credentials#db_connection_string"
  }
}
```

Format: `vault:{kv-v2-path}#{field-name}`

---

## Step 4 — Update Program.cs

Add just **2 lines** before `builder.Build()`:

```csharp
using YourApp.Vault;   // ← add this using at the top

var builder = WebApplication.CreateBuilder(args);

// ════════════════════════════════════════════════════
// ADD THESE 2 LINES — resolve vault: secrets at startup
builder.Configuration.AddEnvironmentVariables(); // picks up Vault__SecretId
await builder.ResolveVaultSecretsAsync();
// ════════════════════════════════════════════════════

builder.Services.AddControllers();
// ... rest of your existing Program.cs unchanged ...

var app = builder.Build();
app.Run();
```

That's it. **Nothing else in your project changes.**

---

## Step 5 — Set the SecretId (never in appsettings.json)

### Local development (your machine):
```cmd
:: Windows
set Vault__SecretId=your-actual-secret-id

:: Then run
dotnet run
```

```bash
# Linux / Mac
export Vault__SecretId=your-actual-secret-id
dotnet run
```

### Production / CI-CD pipeline:
Add `Vault__SecretId` as an environment variable in your deployment pipeline.
The double underscore `__` is .NET's way of reading nested config from env vars.

---

## Step 6 — Store secrets in Vault (one-time, ask Vault admin)

```bash
# Store all your secrets at one path
vault kv put secret/apigee/credentials \
  api_password="real_api_password" \
  db_connection_string="Server=prod;Password=real_db_pass;" \
  payment_password="real_payment_pass"
```

The field names after `#` in your vault: references must match
what you store in Vault.

---

## What happens at startup (runtime flow)

```
dotnet run
  │
  ├── Reads appsettings.json
  │     Password = "vault:secret/data/apigee/credentials#api_password"
  │
  ├── ResolveVaultSecretsAsync() called
  │     ├── Reads Vault:Endpoint, Vault:RoleId from appsettings.json
  │     ├── Reads Vault:SecretId from environment variable
  │     ├── POST /v1/auth/approle/login  →  gets Vault token
  │     ├── GET  /v1/secret/data/apigee/credentials
  │     └── Replaces Password IN MEMORY with real value
  │
  ├── builder.Build() — app starts normally
  │
  └── config["ExternalServices:ApigeeGateway:Password"]
        returns real password ✅  (your code unchanged)
```

---

## If IOptions<T> is used in your project

If your project uses strongly typed settings like `IOptions<ApigeeSettings>`,
pass the settings object to the resolver:

```csharp
// In Program.cs
var apigeeSettings = new ApigeeSettings();
builder.Configuration.GetSection("ExternalServices:ApigeeGateway").Bind(apigeeSettings);

await builder.ResolveVaultSecretsAsync(typedSettingsObject: apigeeSettings);

// Register the resolved object
builder.Services.AddSingleton(apigeeSettings);

// In your service — NO CHANGE NEEDED
public class ApigeeService
{
    private readonly ApigeeSettings _settings;
    public ApigeeService(ApigeeSettings settings) => _settings = settings;

    public void DoWork()
    {
        var pwd = _settings.Password; // ← real value, resolved at startup ✅
    }
}
```

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `Vault:SecretId is missing` | Env var not set | Run `set Vault__SecretId=xxx` before dotnet run |
| `AppRole login failed (400)` | Wrong Role ID or Secret ID | Double-check values with Vault admin |
| `AppRole login failed (403)` | Secret ID expired or used | Generate a new Secret ID from Vault |
| `Field 'xyz' not found` | Wrong field name in vault: reference | Check field name matches what's stored in Vault |
| `secret fetch failed (404)` | Wrong secret path | Check path with `vault kv get secret/apigee/credentials` |
| App refuses to start | One or more secrets failed | Check logs — Vault may be unreachable |
